% GP toolbox
% Version 0.11		Saturday 13 Jan 2007 at 01:20
% Copyright (c) 2007 Neil D. Lawrence
% 
% DEMSPGP1D1 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D2 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D3 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D4 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1DPLOT Plot results from 1-D sparse GP.
% GPBLOCKINDICES Return indices of given block.
% GPCOMPUTEALPHA Update the vector `alpha' for computing posterior mean quickly.
% GPCOMPUTEM Compute the matrix m given the model.
% GPCOVGRADS Sparse objective function gradients wrt Covariance functions for inducing variables.
% GPCOVGRADSTEST Test the gradients of the likelihood wrt the covariance.
% GPCREATE Create a GP model with inducing varibles/pseudo-inputs.
% GPDATAINDICES Return indices of present data.
% GPDISPLAY Display a Gaussian process model.
% GPEXPANDPARAM Expand a parameter vector into a GP model.
% GPEXTRACTPARAM Extract a parameter vector from a GP model.
% GPGRADIENT Gradient wrapper for a GP model.
% GPLOGLIKEGRADIENTS Compute the gradients for the parameters and X.
% GPLOGLIKELIHOOD Compute the log likelihood of a GP.
% GPMEANFUNCTIONGRADIENT Compute the log likelihood gradient wrt the scales.
% GPOBJECTIVE Wrapper function for GP objective.
% GPOBJECTIVEGRADIENT Wrapper function for GP objective and gradient.
% GPOPTIMISE Optimise the inducing variable based kernel.
% GPOPTIONS Return default options for GP model.
% GPOUT Evaluate the output of an Gaussian process model.
% GPPOINTLOGLIKELIHOOD Log-likelihood of a test point for a GP.
% GPPOSTERIORGRADMEANCOVAR Gadient of the mean and variances of the posterior at points given by X.
% GPPOSTERIORGRADMEANVAR Gadient of the mean and variances of the posterior at points given by X.
% GPPOSTERIORMEANCOVAR Mean and covariances of the posterior at points given by X.
% GPPOSTERIORMEANCOVARTEST Test the gradients of the mean and covariance.
% GPPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% GPSCALEBIASGRADIENT Compute the log likelihood gradient wrt the scales.
% GPTEST Test the gradients of the gpCovGrads function and the gp models.
% GPTOOLBOXES Load in the relevant toolboxes for GP.
% GPUPDATEAD Update the representations of A and D associated with the model.
% GPUPDATEKERNELS Update the kernels that are needed.
