
% GPTOOLBOXES Load in the relevant toolboxes for GP.
%
%	Description:
%	% 	gpToolboxes.m CVS version 1.4
% 	gpToolboxes.m SVN version 545
% 	last update 2009-10-08T13:16:47.000000Z
importLatest('netlab');
importLatest('mocap');
importLatest('ndlutil');
importLatest('prior');
importLatest('mltools');
importLatest('mocap')
importLatest('optimi');
importLatest('datasets');
importLatest('kern');
importLatest('noise'); % Only needed for C++ load ins.