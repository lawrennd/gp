
% GPTOOLBOXES Load in the relevant toolboxes for GP.
%
%	Description:
%	% 	gpToolboxes.m CVS version 1.4
% 	gpToolboxes.m SVN version 101
% 	last update 2008-10-05T23:05:54.000000Z
importLatest('netlab');
importLatest('mocap');
importLatest('ndlutil');
importLatest('prior');
importLatest('mltools');
importLatest('optimi');
importLatest('datasets');
importLatest('kern');
importLatest('noise'); % Only needed for C++ load ins.