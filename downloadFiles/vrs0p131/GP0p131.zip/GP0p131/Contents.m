% GP toolbox
% Version 0.131		11-Oct-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% GPRECONSTRUCT Reconstruct an GP form component parts.
% GPPOSTERIORGRADMEANCOVAR Gadient of the mean and variances of the posterior at points given by X.
% GPDISPLAY Display a Gaussian process model.
% GPREADFROMFILE Load a file produced by the C++ implementation.
% GPSCALEBIASGRADIENT Compute the log likelihood gradient wrt the scales.
% GPOPTIONS Return default options for GP model.
% GPUPDATEKERNELS Update the kernels that are needed.
% GPCOMPUTEALPHA Update the vector `alpha' for computing posterior mean quickly.
% GPCOVGRADS Sparse objective function gradients wrt Covariance functions for inducing variables.
% GPTOOLBOXES Load in the relevant toolboxes for GP.
% GPBLOCKINDICES Return indices of given block.
% GPLOGLIKELIHOOD Compute the log likelihood of a GP.
% DEMSPGP1D1 Do a simple 1-D regression after Snelson & Ghahramani's example.
% GPMEANFUNCTIONGRADIENT Compute the log likelihood gradient wrt the scales.
% GPTEST Test the gradients of the gpCovGrads function and the gp models.
% GPOUT Evaluate the output of an Gaussian process model.
% GPSUBSPACEEXTRACTPARAM
% GPPOSTERIORMEANCOVAR Mean and covariances of the posterior at points given by X.
% GPOPTIMISE Optimise the inducing variable based kernel.
% GPPOSTERIORGRADMEANVAR Gadient of the mean and variances of the posterior at points given by X.
% DEMSPGP1D2 Do a simple 1-D regression after Snelson & Ghahramani's example.
% GPCREATE Create a GP model with inducing varibles/pseudo-inputs.
% GPWRITETOFILE Write a file to be read by the C++ implementation.
% GPSUBSPACEOUT
% GPSUBSPACEOPTIMISE
% GPSUBSPACECREATE 
% DEMSPGP1DPLOT Plot results from 1-D sparse GP.
% GPDATAINDICES Return indices of present data.
% GPPOSTERIORMEANCOVARTEST Test the gradients of the mean and covariance.
% GPEXTRACTPARAM Extract a parameter vector from a GP model.
% GPPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% GPPOINTLOGLIKELIHOOD Log-likelihood of a test point for a GP.
% GPEXPANDPARAM Expand a parameter vector into a GP model.
% GPUPDATEAD Update the representations of A and D associated with the model.
% DEMSPGP1D3 Do a simple 1-D regression after Snelson & Ghahramani's example.
% GPDECONSTRUCT break GP in pieces for saving.
% GPOBJECTIVEGRADIENT Wrapper function for GP objective and gradient.
% GPREADFROMFID Load from a FID produced by the C++ implementation.
% GPCOVGRADSTEST Test the gradients of the likelihood wrt the covariance.
% DEMSPGP1D4 Do a simple 1-D regression after Snelson & Ghahramani's example.
% GPOBJECTIVE Wrapper function for GP objective.
% GPCOMPUTEM Compute the matrix m given the model.
% GPGRADIENT Gradient wrapper for a GP model.
% GPLOGLIKEGRADIENTS Compute the gradients for the parameters and X.
% GPSUBSPACEEXPANDPARAM 
