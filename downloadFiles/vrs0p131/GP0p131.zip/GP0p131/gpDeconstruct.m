function [kern, noise, gpInfo] = gpDeconstruct(model)

% GPDECONSTRUCT break GP in pieces for saving.
%
%	Description:
%
%	[KERN, NOISE, GPINFO] = GPDECONSTRUCT(MODEL) takes an GP model
%	structure and breaks it into component parts for saving.
%	 Returns:
%	  KERN - the kernel component of the GP model.
%	  NOISE - the noise component of the GP model.
%	  GPINFO - a structure containing the other information from the GP:
%	   what the sparse approximation is, what the inducing variables are.
%	 Arguments:
%	  MODEL - the model that needs to be saved.
%	
%
%	See also
%	GPRECONSTRUCT


%	Copyright (c) 2007 Neil D. Lawrence
% 	gpDeconstruct.m SVN version 3
% 	last update 2007-11-03T14:35:02.000000Z

kern = model.kern;
if isfield(model, 'noise')
  noise = model.noise;
else
  noise = [];
end
gpInfo.learnScales = model.learnScales;
gpInfo.approx = model.approx;
switch model.approx
 case 'ftc'
 case {'dtc', 'fitc', 'pitc'}
  gpInfo.beta = model.beta;
  gpInfo.betaTransform = model.betaTransform;
  gpInfo.fixInducing = model.fixInducing;
  if model.fixInducing
    gpInfo.inducingIndices = model.inducingIndices;
  else
    gpInfo.X_u = model.X_u;
  end
end
gpInfo.type = 'gp';
gpInfo.scale = model.scale;
gpInfo.bias = model.bias;
gpInfo.d = model.d;
gpInfo.q = model.q;
gpInfo.k = model.k;
gpInfo.N = model.N;