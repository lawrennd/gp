% GP toolbox
% Version 0.1		Saturday 18 Nov 2006 at 22:10
% Copyright (c) 2006 Neil D. Lawrence
% 
% GPUPDATEKERNELS Update the kernels that are needed.
% GPGRADIENT Gradient wrapper for a GP model.
% GPLOGLIKELIHOOD Compute the log likelihood of a GP.
% DEMSPGP1D1 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D2 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D3 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D4 Do a simple 1-D regression after Snelson & Ghahramani's example.
% GPOPTIMISE Optimise the inducing variable based kernel.
% GPPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% GPOBJECTIVE Wrapper function for GP objective.
% GPDISPLAY Display a Gaussian process model.
% GPDATAINDICES Return indices of present data.
% GPCOVGRADSTEST Test the gradients of the likelihood wrt the covariance.
% GPCOMPUTEM Compute the matrix m given the model.
% GPBLOCKINDICES Return indices of given block.
% GPPOSTERIORGRADMEANVAR Gadient of the mean and variances of the posterior at points given by X.
% GPPOSTERIORGRADMEANCOVAR Gadient of the mean and variances of the posterior at points given by X.
% GPPOSTERIORMEANCOVAR Mean and covariances of the posterior at points given by X.
% GPSCALEBIASGRADIENT Compute the log likelihood gradient wrt the scales.
% GPEXTRACTPARAM Extract a parameter vector from a GP model.
% GPOUT Evaluate the output of an Gaussian process model.
% GPLOGLIKEGRADIENTS Compute the gradients for the parameters and X.
% DEMSPGP1DPLOT Plot results from 1-D sparse GP.
% GPCOVGRADS Sparse objective function gradients wrt Covariance functions for inducing variables.
% GPOPTIONS Return default options for GP model.
% GPEXPANDPARAM Expand a parameter vector into a GP model.
% GPCREATE Create a GP model with inducing varibles/pseudo-inputs.
% GPPOSTERIORMEANCOVARTEST Test the gradients of the mean and covariance.
% GPCOMPUTEALPHA Update the vector `alpha' for computing posterior mean quickly.
% GPUPDATEAD Update the representations of A and D associated with the model.
