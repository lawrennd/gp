
% GPTOOLBOXES Load in the relevant toolboxes for GP.
%
%	Description:
%	% 	gpToolboxes.m CVS version 1.4
% 	gpToolboxes.m SVN version 1407
% 	last update 2011-04-05T07:51:19.000000Z
importLatest('netlab');
importLatest('mocap');
importLatest('ndlutil');
importLatest('prior');
importLatest('mltools');
importLatest('mocap')
importLatest('optimi');
importLatest('datasets');
importLatest('kern');
importLatest('noise'); % Only needed for C++ load ins.